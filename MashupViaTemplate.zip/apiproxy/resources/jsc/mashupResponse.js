// called when the template contains {{uuid}}
Handlebars.registerHelper("uuid", function() {
  function s4() {
    return Math.floor((1 + Math.random()) * 0x10000)
      .toString(16)
      .substring(1);
  }
  return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
    s4() + '-' + s4() + s4() + s4();
});

// called when the template contains {{request}}
Handlebars.registerHelper("request", function() {
  return context.getVariable('originalRequest')
})

// called when the template contains {{response}}
Handlebars.registerHelper("response", function() {
  return context.getVariable('response.content')
})

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

// populate the template, passing in an object that includes myArray
var result = populateTemplate(properties.hbr, {'myArray': [1,2,3,4,5]})
// set the response content to be the template populated by Handlebars
context.setVariable('response.content', result)
