Handlebars.registerHelper("uuid", function() {
  function s4() {
    return Math.floor((1 + Math.random()) * 0x10000)
      .toString(16)
      .substring(1);
  }
  return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
    s4() + '-' + s4() + s4() + s4();
});


Handlebars.registerHelper("zip", function() {
  context.setVariable('target.copy.queryparams', false)
  context.setVariable('request.verb', 'POST')
  context.setVariable('request.header.Content-Type', 'text/xml; charset=utf-8')
  context.setVariable('request.header.SOAPAction', 'http://ws.cdyne.com/WeatherWS/GetCityWeatherByZIP')
  return context.getVariable('request.queryparam.zipcode')
})


Handlebars.registerHelper("costCenters", function() {
  return context.getVariable('response.content')
})


/////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////


var result = populateTemplate(properties.hbr, {'myArray': [1,2,3,4,5]})
context.setVariable('request.content', result)
